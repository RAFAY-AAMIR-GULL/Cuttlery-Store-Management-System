package MainPackage;

public class employee 
{
	public String name;
	public String gender;
	public String salary;
	public String post;
	public String id;
	public String password;
	public employee()
	{
		
	}

}
